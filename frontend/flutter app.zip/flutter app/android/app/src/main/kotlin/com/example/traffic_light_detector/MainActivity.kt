package com.example.traffic_light_detector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
